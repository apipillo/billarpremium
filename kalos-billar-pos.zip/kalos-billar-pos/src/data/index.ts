import { isFirebaseConfigured } from '../lib/firebase'
import { FirestoreStore } from './firestoreStore'
import { LocalStore } from './localStore'
import type { Store } from './store'

let storeInstance: Store | null = null

/**
 * Devuelve la implementación activa:
 *  - Por defecto usa LocalStore (demo, sin backend) para que el prototipo se
 *    visualice correctamente en cualquier hosting estático (GitHub Pages/Vercel).
 *  - Si se fuerza VITE_DEMO_MODE=false y Firebase está configurado, usa FirestoreStore
 *    (nube, con caché en memoria y tiempo real).
 */
export function getStore(): Store {
  if (storeInstance) return storeInstance

  const forceCloud = import.meta.env.VITE_DEMO_MODE === 'false'
  if (forceCloud && isFirebaseConfigured()) {
    try {
      storeInstance = new FirestoreStore()
    } catch (err) {
      console.warn('Fallo al inicializar FirestoreStore, usando LocalStore de respaldo:', err)
      storeInstance = new LocalStore()
    }
  } else {
    storeInstance = new LocalStore()
  }
  return storeInstance
}

export type { Store }
