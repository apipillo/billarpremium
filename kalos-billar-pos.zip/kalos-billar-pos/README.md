﻿# Kalos Billar Club — Punto de Venta (POS)

Web App **Punto de Venta premium para billar**, 100 % responsive (Android, iPhone, tablet y escritorio), con
**menú de iconos**, **tema oscuro premium**, el logo de **Kalos Billar Club** y **datos en tiempo real**.

> Renta de mesas por **tiempo cronometrado exacto** + venta de productos (cerveza, refrescos, botana),
> reservas, portal del jugador, gestión de cajeros, notificaciones en vivo y reportes de ocupación.

---

## ✨ Funcionalidades

| Módulo | Descripción |
| --- | --- |
| 🎱 Mesas | Tablero en tiempo real con paño de billar y cronómetro por mesa (libre / rentada / pausada / limpieza / mantenimiento). |
| ⏱ Renta por tiempo | Inicio / pausa / reanudar. Tiempo facturable = transcurrido − pausas; orden **mínimo → redondeo** (exacto / minuto / cuarto de hora / hora). |
| 🧾 Cuenta de mesa | Agregar productos a la mesa al rentar (cerveza, refresco, botana); IVA 16 %, propina, cobro y recibo. |
| 📅 Reservas | Crear reservas por mesa, fecha/hora, duración, depósito y pre-orden de productos. |
| 👤 Portal del jugador | Vista pública para pedir productos desde la mesa (vía QR). |
| 🪑 Mesa cliente | Vista de autoservicio escaneable por QR (`#/mesa-cliente/:tableId`). |
| 👥 Gestión de cajeros | El administrador crea cajeros con usuario y PIN; control de acceso. |
| 🔔 Notificaciones | Alertas en vivo + push (Firebase Cloud Messaging) y sonidos de billar. |
| 📈 Reportes | KPIs: ventas, horas rentadas, ocupación, top productos, ventas por mesa. |
| 🏦 Caja | Apertura / cierre de turno con arqueo y bitácora de auditoría. |
| 🔐 Roles | Admin, Cajero y Jugador; auditoría inmutable de eventos. |

---

## 🛠 Stack

- **React 19 + Vite 8 + TypeScript** · **Tailwind CSS 4** · **lucide-react** · **motion**
- **Firebase 13** (Firestore + Authentication + Cloud Messaging) · **react-router-dom 7**

---

## 🚀 Ejecutar en local

```bash
pnpm install
pnpm dev        # http://localhost:3000
pnpm build      # genera dist/
pnpm preview    # sirve la build de producción
```

> **Modo demo por defecto** (`VITE_DEMO_MODE=true` en `.env.production`): funciona sin backend, con datos de
> ejemplo y sin credenciales. Ideal para visualizar el prototipo.

---

## 🌐 Despliegue gratuito (GitHub Pages y Vercel)

El proyecto ya viene configurado (`base: './'` + HashRouter), por lo que funciona en **subrutas** y en cualquier
dominio, e incluso abriendo `dist/index.html` directamente.

### GitHub Pages

1. Sube la carpeta a un repositorio nuevo de GitHub.
2. Ve a **Settings → Pages** y elige **Source: GitHub Actions**.
3. Haz `push` a `main`. El workflow `.github/workflows/deploy.yml` compila y publica en
   `https://<usuario>.github.io/<repo>/`.

### Vercel

1. En [vercel.com](https://vercel.com) → **Add New → Project** e importa el repositorio (o sube la carpeta).
2. Vercel detecta Vite y `vercel.json` automáticamente (usa `pnpm build` y publica `dist/`).
3. Obtienes una URL tipo `https://kalos-billar-pos.vercel.app`.

---

## ☁️ Conectar Firebase (producción)

El proyecto ya incluye la config de un proyecto Firebase (`firebase-applet-config.json`), las reglas de
seguridad (`firestore.rules`) y los índices (`firestore.indexes.json`).

1. Cambia a **nube**: pon `VITE_DEMO_MODE=false` (edita `.env.production` o configura la variable en el hosting).
2. Despliega reglas e índices: `firebase deploy --only firestore:rules,firestore:indexes` (o desde la consola).
3. Habilita **Authentication** (Google + Email/Password) y **Cloud Messaging** en tu proyecto Firebase.
4. Si usas otro proyecto Firebase, reemplaza `firebase-applet-config.json` por tu propia config.

---

## 📁 Arquitectura

```
src/
├── lib/          # Dominio puro: types, time (cronómetro/redondeo), billing, money, format, seed, firebase, notifications
├── data/         # Repositorio: Store (interfaz) → LocalStore (demo) | FirestoreStore (nube)
├── state/        # AppContext (estado global, acciones, notificaciones, toasts)
├── components/   # Shell (menú de iconos), TableCard, ProductTile, Modal, Logo, NotificationCenter
└── screens/      # Login, Mesas, MesasActivas, Reservas, CuentaMesa, MesaCliente, PortalJugador, Productos, Ventas, Caja, Reportes, Ajustes, GestionCajeros
```

La **lógica de negocio vive en `lib/`** (pura), separada de la persistencia (`data/`) y de la UI (`screens/`).
Esto permite alternar entre modo demo y Firestore sin tocar la lógica.

---

## 📚 Investigación previa

La investigación original está en [`docs/`](docs/): funcionalidades de POS, due diligence de repositorios GitHub,
especificación de cobro por tiempo y guía de diseño.
